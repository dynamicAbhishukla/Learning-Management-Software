﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LMS.Controllers
{

    public class StudentController : Controller
    {

        SqlConnection con = new SqlConnection("Data Source=ABHINAV-LENOVO\\SQLEXPRESS;Initial Catalog=LMS;Integrated Security=True;");
        // GET: Student
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Dashboard()
        {
            return View();
        }
        public ActionResult Courses()
        {
            string query = " select * from tbl_category order by sr desc";
            SqlDataAdapter adapter = new SqlDataAdapter(query,con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            ViewBag.data = dt;
            return View();
        }
        public ActionResult SoftwareKit()
        {
            return View();
        }
        public ActionResult task() 
        {
            return View();
        }
        public ActionResult Notes()
        {
            return View();  
        }
        public ActionResult videos(int? catid)
        {
            if (catid.HasValue)
            {
                int batchid = Convert.ToInt32(Session["batch"]);
                string query = "select * from tbl_video where batch={batchid} and category={catid} order by sr";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                ViewBag.video = dt;
                return View();
            }
            else
            {
                return Content("<script>alert('please select video category');location.href='/student/Courses'</script>");
            }
            
        } 
        public ActionResult ChangePassword()
        {
            return View();
        }
        public ActionResult logout()
        {
            Session.RemoveAll();
            return Content("<script>location.href='/home/Index'</script>");
        }
    }
}