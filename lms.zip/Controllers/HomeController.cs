﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LMS.Controllers
{

    public class HomeController : Controller
    {
        SqlConnection con = new SqlConnection("Data Source=ABHINAV-LENOVO\\SQLEXPRESS;Initial Catalog=LMS;Integrated Security=True;");
        // GET: Home

        public ActionResult Index()
        {
            // select batch
            string query = "select * from tbl_batch order by sr desc";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            ViewBag.table1 = dt;
            return View();
        }
        [HttpPost]

        // save student data on clicking submit button in register section
        public ActionResult saveuser(string txt_name, long txt_mobno, string txt_email, string txt_password, string ddl_course, string ddl_year,HttpPostedFileBase file_profile, int ddl_batch)
        {
            string query = $"insert into tbl_student values('{txt_name}','{txt_mobno}','{txt_email}','{txt_password}','{ddl_course}','{ddl_year}','{file_profile.FileName}',{ddl_batch},0,'{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss")}')";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result > 0)
            {
                file_profile.SaveAs(Server.MapPath("/Content/profilepic/" + file_profile.FileName));
                return Content("<script>alert('You have registered Successfully.');location.href='/home/Index'</script>");
            }
            else
            {

                return Content("<script>alert('Try Again!');location.href='/home/Index'</script>");
            }

        }

        [HttpPost]
        public ActionResult getInTouch( string firstname, string lastname, string emailid, long? phonenumber, string subjectname, string message)
        {
            
            string query = $"insert into tbl_getInTouch values('{firstname}','{lastname}', '{emailid}',{phonenumber},'{subjectname}','{message}')";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result > 0)
            {

                return Content("<script>alert('data saved successfully!');location.href='/Home/Index'</script>");
            }
            else
            {
                return Content("<script>alert('data not saved, try again!');location.href='/Home/Index'</script>");
            }
          
        }
        [HttpPost]
        public ActionResult login(string email, string password)
        {
            string query = $"select * from tbl_student where emailid='{email}' and password='{password}'";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                if (Convert.ToInt32(dt.Rows[0]["status"]) == 1)
                {
                    Session["name"] = dt.Rows[0]["name"];
                    Session["email"] = dt.Rows[0]["emailid"];
                    Session["batch"] = dt.Rows[0]["batch"];
                    Session["picture"] = dt.Rows[0]["picture"];
                    return Content("<script>alert('Welcome!');location.href='/student/Dashboard'</script>");
               
                }
                else
                {
                    return Content("<script>alert('You are not authorized by admin!');location.href='/home/Index'</script>");
                }

             
            }
            else
            {
                return Content("<script>alert('Invalid Id or Password!');location.href='/admin/Index'</script>");
            }
           
         
        }
    }
}