﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Web.WebPages;

namespace LMS.Controllers
{
    public class AdminController : Controller
    {
        SqlConnection con = new SqlConnection("Data Source=ABHINAV-LENOVO\\SQLEXPRESS;Initial Catalog=LMS;Integrated Security=True;");
        // GET: Admin
        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult AddBatch() 
        {
            // select all data from tbl_batch
            string query = "select * from tbl_batch order by sr desc";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            // transfer data of viewbag to view page
            ViewBag.data = dt;
            return View();
        }

        // insert batch into database
        [HttpPost]
        public ActionResult savebatch( string txt_class) {
            string query = $"insert into tbl_batch values('{txt_class}',1)";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result > 0)
            {
                return Content("<script>alert('Batch added Successfully');location.href='/admin/AddBatch'</script>");
            }
            else
            {

                return Content("<script>alert('Batch not Added');location.href='/admin/AddBatch'</script>");
            }
        }
        public ActionResult addvideocategory()
        {
            string query = "select * from tbl_category order by sr desc";
            SqlDataAdapter adapter = new SqlDataAdapter(query,con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            ViewBag.data = dt;
            return View();
        }
        [HttpPost]
        // add video category into database
        public ActionResult savevideocategory(string txt_category,HttpPostedFileBase file_thumbnail)
        {
            string query = $"insert into tbl_category values('{txt_category}','{file_thumbnail.FileName}','{DateTime.Now.ToString("yyyy-MM-dd")}')";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
           if(result> 0)
            {
                file_thumbnail.SaveAs(Server.MapPath("/Content/catpic/" + file_thumbnail.FileName));
                return Content("<script>alert('Video category added Successfully');location.href='/admin/addvideocategory'</script>");
            }
             else
            {
               
                return Content("<script>alert(' video category not Added');location.href='/admin/addvideocategory'</script>");
            }
        }

        // onload event of add video form
        public ActionResult AddVideo()
        {
            // select data from tbl_batch
            string query = "select * from tbl_batch order by sr desc";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            // select data from tbl_category
            string query2 = "select * from tbl_category order by sr desc";
            SqlDataAdapter adapter2 = new SqlDataAdapter(query2, con);
            DataTable dt2 = new DataTable();
            adapter2.Fill(dt2);

            // returning data from the controller to view page on load event using ViewBag object of MVC collection
            ViewBag.table1 = dt;
            ViewBag.table2 = dt2;

            return View();
        }

        // add video in the database on clicking submit button
        [HttpPost]

        public ActionResult savevideo(string txt_title, int ddl_batch, int ddl_category, string txt_desc, string txt_link, HttpPostedFileBase file_thumbnail )
        {
            string query = $"insert into tbl_video values('{txt_title}',{ddl_batch},{ddl_category},'{txt_desc}','{txt_link}','{file_thumbnail.FileName}','{DateTime.Now.ToString("yyyy-MM-dd hh:mm")}')";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result > 0)
            {
                file_thumbnail.SaveAs(Server.MapPath("/Content/videopic/" + file_thumbnail.FileName));
                return Content("<script>alert('video added succesfuly');location.href='/admin/AddVideo'</script>");
            }
            else
            {
                return Content("<script>alert('video not added');location.href='/admin/AddVideo'</script>");
            }

       
        }
        public ActionResult assignmentsubmissionform()
        {   
            //select batch
            string query = "select * from tbl_batch order by sr desc";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            ViewBag.table1 = dt;
            return View();
        }
        [HttpPost]
        // add form on clicking submit button
        public ActionResult saveassignment(int ? ddl_batch,string txt_subject,string txt_title,string txt_desc, HttpPostedFileBase file_assignment, string txt_teacher, DateTime date_lastdate)
        {
            string query = $"insert into tbl_assignment values({ddl_batch},'{txt_subject}','{txt_title}','{txt_desc}','{file_assignment.FileName}','{txt_teacher}','{date_lastdate.ToString("yyyy-MM-dd hh:mm:ss")}','{DateTime.Now.ToString("yyyy-MM-dd")}',1)";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result > 0)
            {
                file_assignment.SaveAs(Server.MapPath("/Content/assignmentpic/" + file_assignment.FileName));
                return Content("<script>alert('assignment added Successfully');location.href='/admin/assignmentsubmissionform'</script>");
            }
            else
            {

                return Content("<script>alert('assignment not Added');location.href='/admin/assignmentsubmissionform'</script>");
            }

        }
        public ActionResult Enquiry()
        {
            return View();
        }
        public ActionResult ManageStudent()
        {
            string query = "select * from tbl_student left join tbl_batch on tbl_student.batch=tbl_batch.sr order by regdate";
            SqlDataAdapter adapter= new SqlDataAdapter(query, con);
            DataTable dt = new DataTable(); 
            adapter.Fill(dt);

            ViewBag.data = dt;
            return View();
        }
        public ActionResult updatestatus(string email, int? status)
        {
            if (!email.IsEmpty() && status.HasValue)
            {
                int s = status == 0 ? 1 : 0;
                string query = $"update tbl_student set status={s} where emailid='{email}'";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                return Content("<script>alert('Status Updated');location.href='/admin/managestudent'</script>");
            }
            else
            {
                return Content("<script>alert('Try again');location.href='/admin/managestudent'</script>");
            }
        }

    }
}